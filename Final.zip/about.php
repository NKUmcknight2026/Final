<?php
// Start the PHP section
$title = "About Us";
$year = date("Y");
$companyName = "Our Company";
$mission = "Our company was founded with the idea that for a small fee we can keep customers up to date with the best available discounts on many online shopping websites.";
$vision = "To be a leading provider in our industry, recognized for quality, integrity, and innovation.";
$teamDescription = "Our team is made up of passionate, skilled professionals dedicated to achieving great results for our clients.";
?>

<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="css/styles.css">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional: CSS file -->
</head>
<body>
    <header>
        <h1>Welcome to <?php echo $companyName; ?></h1>
    </header>
    <main>
        <section>
            <h2>About Us</h2>
            <p><?php echo $mission; ?></p>
        </section>
        <section>
            <h2>Our Vision</h2>
            <p><?php echo $vision; ?></p>
        </section>
        <section>
            <h2>Our Team</h2>
            <p><?php echo $teamDescription; ?></p>
        </section>
    </main>
    <footer>
        <p>&copy; <?php echo $year; ?> <?php echo $companyName; ?>. All rights reserved.</p>
    </footer>
</body>
</html>
