<?php
// Include the database connection file (db.php is in the same folder)
require_once '../db.php';

$items = [];

try {
    // Fetch all items from the 'items' table
    $query = "SELECT id, name, description, price, stock FROM items";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    // Fetch the results as an associative array
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Log the error for debugging
    error_log("Error fetching items: " . $e->getMessage());

    // Display a user-friendly error message
    $errorMessage = "An error occurred while fetching the items. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items List</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <h1>Items List</h1>

    <?php if (isset($errorMessage)): ?>
        <p class="error"><?= htmlspecialchars($errorMessage); ?></p>
    <?php elseif (empty($items)): ?>
        <p>No items found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['id']); ?></td>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td><?= htmlspecialchars($item['description']); ?></td>
                        <td><?= htmlspecialchars($item['price']); ?></td>
                        <td><?= htmlspecialchars($item['stock']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
