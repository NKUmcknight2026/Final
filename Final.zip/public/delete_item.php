<?php
require_once '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Delete the item from the database
        $stmt = $pdo->prepare("DELETE FROM items WHERE id = ?");
        $stmt->execute([$id]);

        // Redirect to the list page after successful deletion
        header('Location: list_items.php');
        exit;
    } catch (PDOException $e) {
        // Log the error for debugging
        error_log("Error deleting item: " . $e->getMessage());

        // Display a user-friendly error message
        echo "<p style='color: red;'>An error occurred while deleting the item. Please try again later.</p>";
    }
} else {
    // Display a user-friendly message for invalid requests
    echo "<p style='color: red;'>Invalid request. No item ID provided.</p>";
}
?>
