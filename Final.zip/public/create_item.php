<?php
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    try {
        // Insert new item into the database
        $stmt = $pdo->prepare("INSERT INTO items (title, description) VALUES (?, ?)");
        $stmt->execute([$title, $description]);

        // Redirect to the list page after successful insertion
        header('Location: list_items.php');
        exit;
    } catch (PDOException $e) {
        // Log the error for debugging
        error_log("Error adding item: " . $e->getMessage());

        // Set an error message for the user
        $errorMessage = "An error occurred while adding the item. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Item</title>
    <style>
        .error {
            color: red;
            background-color: #ffebeb;
            padding: 1rem;
            border: 1px solid red;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <h1>Create New Item</h1>

    <?php if (isset($errorMessage)): ?>
        <p class="error"><?= htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="title" placeholder="Title" required><br>
        <textarea name="description" placeholder="Description" required></textarea><br>
        <button type="submit">Create</button>
    </form>
</body>
</html>
