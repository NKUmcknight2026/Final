<?php
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    try {
        // Update the item in the database
        $stmt = $pdo->prepare("UPDATE items SET title = ?, description = ? WHERE id = ?");
        $stmt->execute([$title, $description, $id]);

        // Redirect to the list page after a successful update
        header('Location: list_items.php');
        exit;
    } catch (PDOException $e) {
        // Log the error for debugging
        error_log("Error updating item: " . $e->getMessage());

        // Display a user-friendly error message
        $errorMessage = "An error occurred while updating the item. Please try again later.";
    }
} else {
    $id = $_GET['id'] ?? null;

    if ($id) {
        try {
            // Fetch the current item details
            $stmt = $pdo->prepare("SELECT * FROM items WHERE id = ?");
            $stmt->execute([$id]);
            $item = $stmt->fetch();

            if (!$item) {
                $errorMessage = "Item not found.";
            }
        } catch (PDOException $e) {
            // Log the error for debugging
            error_log("Error fetching item: " . $e->getMessage());

            // Display a user-friendly error message
            $errorMessage = "An error occurred while fetching the item details. Please try again later.";
        }
    } else {
        $errorMessage = "Invalid request. No item ID provided.";
    }
}
?>

<h1>Edit Item</h1>

<?php if (isset($errorMessage)): ?>
    <p style="color: red;"><?= htmlspecialchars($errorMessage); ?></p>
<?php elseif (isset($item)): ?>
    <form method="post">
        <input type="hidden" name="id" value="<?= htmlspecialchars($item['id']); ?>">
        <input type="text" name="title" value="<?= htmlspecialchars($item['title']); ?>" required>
        <textarea name="description" required><?= htmlspecialchars($item['description']); ?></textarea>
        <button type="submit">Save Changes</button>
    </form>
<?php endif; ?>
