<?php 
// Include the database connection
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize the form data
    $Username = trim($_POST['Username']);
    $Email = trim($_POST['Email']);
    $Password = trim($_POST['Password']);

    // Simple validation
    if (!empty($Username) && !empty($Email) && !empty($Password)) {
        // Hash the Password
        $hashed_Password = Password_hash($Password, Password_DEFAULT);

        // Prepare the SQL query to insert the new user (without the Role column)
        $sql = "INSERT INTO users (Username, Password, Email) VALUES (:Username, :Password, :Email)";
        $stmt = $pdo->prepare($sql);
        
        // Bind the parameters and execute the query
        $stmt->bindParam(':Username', $Username);
        $stmt->bindParam(':Password', $hashed_Password);
        $stmt->bindParam(':Email', $Email);
        
        // Check if the query was successful
        if ($stmt->execute()) {
            echo "Registration successful! <a href='login.php'>Login here</a>";
        } else {
            echo "Error registering user.";
        }
    } else {
        echo "Please fill in all fields.";
    }
}
?>
<link rel="stylesheet" href="css/styles.css">
