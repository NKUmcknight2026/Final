<?php
session_start();
require 'db.php'; // Relative path to db.php

// Initialize featured items as an empty array
$featuredItems = [];

try {
    // Fetch featured items to display on the homepage
    $stmt = $pdo->query("SELECT * FROM items ORDER BY created_at DESC LIMIT 5");
    $featuredItems = $stmt->fetchAll();
} catch (PDOException $e) {
    // Log the error to a file for debugging
    error_log("Error fetching featured items: " . $e->getMessage(), 0);

    // Display a user-friendly error message
    $errorMessage = "We are experiencing technical issues. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="css/styles.css">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Site</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <header>
        <h1>Welcome to Our Site</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="public/list_items.php">View Items</a></li>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li><a href="admin/dashboard.php">Admin Dashboard</a></li>
                    <?php endif; ?>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Featured Items</h2>
        <?php if (isset($errorMessage)): ?>
            <p style="color: red;"><?= htmlspecialchars($errorMessage); ?></p>
        <?php else: ?>
            <ul>
                <?php if (!empty($featuredItems)): ?>
                    <?php foreach ($featuredItems as $item): ?>
                        <li>
                            <a href="item_detail.php?id=<?= htmlspecialchars($item['id']); ?>">
                                <?= htmlspecialchars($item['title']); ?>
                            </a>
                            <p><?= htmlspecialchars($item['description']); ?></p>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No featured items to display.</p>
                <?php endif; ?>
            </ul>
        <?php endif; ?>

        <a href="public/list_items.php" class="btn">View All Items</a>
    </main>

    <footer>
        <p>&copy; <?= date('Y'); ?> Your Company. All rights reserved.</p>
    </footer>
</body>
</html>
