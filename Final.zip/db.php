<?php
$host = '127.0.0.1'; // Database host (localhost)
$dbname = 'amazon_sales'; // Database name (the one you just created)
$username = 'root'; // Default XAMPP username for MySQL
$password = ''; // Default password is empty for XAMPP's root user

try {
    // Create a new PDO instance to connect to the MySQL database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Set the PDO error mode to exception for easier debugging
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Optional: Set the character encoding to UTF-8 for better support
    $pdo->exec("SET NAMES utf8mb4");
    
} catch (PDOException $e) {
    // Log the error for debugging
    error_log("Database connection failed: " . $e->getMessage());

    // Display a user-friendly message
    echo "<p style='color: red;'>We are experiencing technical issues. Please try again later.</p>";
    exit; // Stop further execution gracefully
}
?>
