<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = $_POST['item_name'];

    // Generate a unique ID for the item (simple incrementing logic)
    $itemID = uniqid();
    
    // Save the item to items.txt
    $file = fopen('items.txt', 'a');
    fwrite($file, "$itemID|$itemName\n");
    fclose($file);
    
    $successMessage = 'Item created successfully!';
}
?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../css/styles.css">
<head>
    <title>Create New Item</title>
</head>
<body>
    <h1>Create New Item</h1>
    <?php if ($successMessage): ?>
        <p style="color: green;"><?php echo $successMessage; ?></p>
    <?php endif; ?>
    <form method="POST">
        <label for="item_name">Item Name:</label>
        <input type="text" name="item_name" required>
        <br>
        <button type="submit">Create</button>
    </form>
    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
