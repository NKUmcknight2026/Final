<?php
require_once 'awards.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Instantiate the Award class
$awardObj = new Award($pdo);

// Get the award ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    $award = $awardObj->getAwardById($id);
    if (!$award) {
        echo "Award not found.";
        exit;
    }
} else {
    echo "No award ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Award Details</title>
</head>
<body>
    <h1>Award Details</h1>
    <p><strong>ID:</strong> <?php echo htmlspecialchars($award['id']); ?></p>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($award['name']); ?></p>
    <p><strong>Description:</strong> <?php echo htmlspecialchars($award['description']); ?></p>
    <p><strong>Date Awarded:</strong> <?php echo htmlspecialchars($award['date_awarded']); ?></p>

    <a href="index.php">Back to Awards List</a>
</body>
</html>
