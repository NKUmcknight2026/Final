<?php
require_once 'awards.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Instantiate the Award class
$award = new Award($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $date_awarded = $_POST['date_awarded'] ?? date('Y-m-d');

    // Call the createAward method
    if ($award->createAward($name, $description, $date_awarded)) {
        header("Location: index.php"); // Redirect back to the awards list on success
        exit;
    } else {
        echo "Error creating award.";
    }
}
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">

<head>
    <title>Create New Award</title>
</head>
<body>
    <h1>Create New Award</h1>
    <form method="POST">
        <label for="title">Title:</label>
        <input type="text" name="title" required><br>

        <label for="description">Description:</label>
        <textarea name="description" required></textarea><br>

        <label for="date_awarded">Date Awarded:</label>
        <input type="date" name="date_awarded" required><br>

        <button type="submit">Create Award</button>
    </form>
</body>
</html>
