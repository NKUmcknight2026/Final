<?php
require_once '../../db.php';

class Award {
    private $pdo;

    public function __construct($dbConnection) {
        $this->pdo = $dbConnection;
    }

    public function createAward($name, $description, $date_awarded) {
        $stmt = $this->pdo->prepare("INSERT INTO awards (name, description, date_awarded) VALUES (?, ?, ?)");
        return $stmt->execute([$name, $description, $date_awarded]);
    }

    public function getAwardById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM awards WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllAwards() {
        $stmt = $this->pdo->query("SELECT * FROM awards");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateAward($id, $name, $description, $date_awarded) {
        $stmt = $this->pdo->prepare("UPDATE awards SET name = ?, description = ?, date_awarded = ? WHERE id = ?");
        return $stmt->execute([$name, $description, $date_awarded, $id]);
    }

    public function deleteAward($id) {
        $stmt = $this->pdo->prepare("DELETE FROM awards WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
