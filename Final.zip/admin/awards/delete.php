<?php
require_once 'awards.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Instantiate the Award class
$awardObj = new Award($pdo);

// Get the award ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    if ($awardObj->deleteAward($id)) {
        header("Location: index.php"); // Redirect to the awards list after successful deletion
        exit;
    } else {
        echo "Error deleting award.";
    }
} else {
    echo "No award ID provided.";
    exit;
}
?>
