<?php
require_once 'awards.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Instantiate the Award class
$awardObj = new Award($pdo);

// Get the award ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    $award = $awardObj->getAwardById($id);
    if (!$award) {
        echo "Award not found.";
        exit;
    }
} else {
    echo "No award ID provided.";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $date_awarded = $_POST['date_awarded'] ?? date('Y-m-d');

    if ($awardObj->updateAward($id, $name, $description, $date_awarded)) {
        header("Location: index.php"); // Redirect to awards list on success
        exit;
    } else {
        echo "Error updating award.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Award</title>
</head>
<body>
    <h1>Edit Award</h1>
    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($award['name']); ?>" required><br>

        <label for="description">Description:</label>
        <textarea name="description" required><?php echo htmlspecialchars($award['description']); ?></textarea><br>

        <label for="date_awarded">Date Awarded:</label>
        <input type="date" name="date_awarded" value="<?php echo htmlspecialchars($award['date_awarded']); ?>" required><br>

        <button type="submit">Update Award</button>
    </form>

    <a href="index.php">Back to Awards List</a>
</body>
</html>
