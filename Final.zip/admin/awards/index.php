<?php
// Include the database connection and the Award class
require_once '../../db.php'; 
require_once 'awards.php';  

// Create an instance of the Award class
$awardClass = new Award($pdo);

// Fetch all awards using the getAllAwards method
$awards = $awardClass->getAllAwards();
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">
<head>
    <title>Awards List</title>
</head>
<body>
    <h1>Awards</h1>
    <a href="create.php">Create New Award</a>
    <table border="1">
        <tr>
            <th>Award ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($awards as $award): ?>
            <tr>
                <td><?php echo $award['id']; ?></td>
                <td><?php echo $award['name']; ?></td>
                <td><?php echo $award['description']; ?></td>
                <td>
                    <a href="detail.php?id=<?php echo $award['id']; ?>">View</a>
                    <a href="edit.php?id=<?php echo $award['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $award['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
