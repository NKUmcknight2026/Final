<?php
require_once '../../db.php'; 

function getAllContacts() {
    global $pdo;
    $query = "SELECT * FROM contacts";
    $result = $pdo->query($query);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getContactById($id) {
    global $pdo;
    $query = "SELECT * FROM contacts WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
