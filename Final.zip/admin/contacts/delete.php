<?php
require_once 'pages.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Get the page ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    if (deletePage($id)) {
        // Redirect to the pages list after successful deletion
        header("Location: index.php");
        exit;
    } else {
        echo "Error deleting page.";
    }
} else {
    echo "No page ID provided.";
    exit;
}
?>
