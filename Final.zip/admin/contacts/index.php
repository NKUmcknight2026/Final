<?php
require_once 'contacts.php';

$contacts = getAllContacts(); 
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">
<head>
    <title>Contact Requests</title>
</head>
<body>
    <h1>Contact Requests</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($contacts as $contact): ?>
            <tr>
                <td><?php echo $contact['id']; ?></td>
                <td><?php echo $contact['name']; ?></td>
                <td><?php echo $contact['email']; ?></td>
                <td><?php echo substr($contact['message'], 0, 50) . '...'; ?></td>  
                <td>
                    <a href="detail.php?id=<?php echo $contact['id']; ?>">View</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
