<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Fetch items and users
require 'db.php';
$items = $pdo->query("SELECT * FROM items")->fetchAll();
$users = $pdo->query("SELECT * FROM users")->fetchAll();
?>
<link rel="stylesheet" href="../css/styles.css">
<h1>Admin Dashboard</h1>
<h2>Manage Items</h2>
<ul>
    <?php foreach ($items as $item): ?>
        <li><?= htmlspecialchars($item['title']); ?> - <a href="edit_item.php?id=<?= $item['id']; ?>">Edit</a> | <a href="delete_item.php?id=<?= $item['id']; ?>">Delete</a></li>
    <?php endforeach; ?>
</ul>

<h2>Manage Users</h2>
<ul>
    <?php foreach ($users as $user): ?>
        <li><?= htmlspecialchars($user['username']); ?> (<?= $user['role']; ?>)</li>
    <?php endforeach; ?>
</ul>
