<?php
require_once 'products.php';  
$id = $_GET['id'];
$product = getProductById($id);  
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Detail</title>
</head>
<body>
    <h1><?php echo $product['name']; ?></h1>
    <p><strong>Description:</strong> <?php echo $product['description']; ?></p>
    <p><strong>Price:</strong> $<?php echo $product['price']; ?></p>
    <a href="edit.php?id=<?php echo $product['id']; ?>">Edit</a>
    <a href="delete.php?id=<?php echo $product['id']; ?>">Delete</a>
    <br>
    <a href="index.php">Back to Products List</a>
</body>
</html>
