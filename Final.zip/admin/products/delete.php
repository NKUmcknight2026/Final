<?php
require_once 'products.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Get the product ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    // Attempt to delete the product
    if (deleteProduct($id)) {
        // Redirect to the product list on successful deletion
        header("Location: index.php");
        exit;
    } else {
        echo "Error deleting product.";
    }
} else {
    echo "No product ID provided.";
    exit;
}
?>
