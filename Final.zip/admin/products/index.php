<?php
require_once 'products.php';  
$products = getAllProducts();  
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">

<head>
    <title>Products List</title>
</head>
<body>
    <h1>Products</h1>
    <a href="create.php">Create New Product</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?php echo $product['id']; ?></td>
                <td><?php echo $product['name']; ?></td>
                <td><?php echo substr($product['description'], 0, 50) . '...'; ?></td> 
                <td><?php echo $product['price']; ?></td>
                <td>
                    <a href="detail.php?id=<?php echo $product['id']; ?>">View</a>
                    <a href="edit.php?id=<?php echo $product['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $product['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
