<?php
require_once '../../db.php';

function getAllTeamMembers() {
    global $pdo;
    $query = "SELECT id, Name, Role, Email, phone FROM team";
    $stmt = $pdo->query($query);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getTeamMemberById($id) {
    global $pdo;
    $query = "SELECT * FROM team WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createTeamMember($data) {
    global $pdo;
    $query = "INSERT INTO team (Name, Role, Email, phone) VALUES (:Name, :Role, :Email, :phone)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':Name', $data['Name'], PDO::PARAM_STR);
    $stmt->bindParam(':Role', $data['Role'], PDO::PARAM_STR);
    $stmt->bindParam(':Email', $data['Email'], PDO::PARAM_STR);
    $stmt->bindParam(':phone', $data['phone'], PDO::PARAM_STR);
    $stmt->execute();
}

function updateTeamMember($id, $data) {
    global $pdo;
    $query = "UPDATE team SET Name = :Name, Role = :Role, Email = :Email, phone = :phone WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':Name', $data['Name'], PDO::PARAM_STR);
    $stmt->bindParam(':Role', $data['Role'], PDO::PARAM_STR);
    $stmt->bindParam(':Email', $data['Email'], PDO::PARAM_STR);
    $stmt->bindParam(':phone', $data['phone'], PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deleteTeamMember($id) {
    global $pdo;
    $query = "DELETE FROM team WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}
?>
