<?php
require_once 'team.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'Name' => $_POST['name'],
        'Role' => $_POST['role'],
        'Email' => $_POST['email'],
        'phone' => $_POST['phone']
    ];

    createTeamMember($data);
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">

<head>
    <title>Add New Team Member</title>
</head>
<body>
    <h1>Add New Team Member</h1>
    <form method="post">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="role">Role:</label>
        <input type="text" name="role" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" required><br>

        <button type="submit">Add</button>
    </form>
</body>
</html>
