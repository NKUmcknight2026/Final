<?php
require_once 'team.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Get the team member ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    if (deleteTeamMember($id)) {
        header("Location: index.php"); // Redirect to the team list on success
        exit;
    } else {
        echo "Error deleting team member.";
    }
} else {
    echo "No team member ID provided.";
    exit;
}
?>
