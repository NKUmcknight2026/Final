<?php
require_once 'team.php';
$teamMembers = getAllTeamMembers();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Team Members</title>
</head>
<link rel="stylesheet" href="../../css/styles.css">

<body>
    <h1>Team Members</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($teamMembers as $member): ?>
            <tr>
                <td><?php echo $member['id']; ?></td>
                <td><?php echo $member['Name']; ?></td>
                <td><?php echo $member['Role']; ?></td>
                <td><?php echo $member['Email']; ?></td>
                <td><?php echo $member['phone']; ?></td>
                <td>
                    <a href="view.php?id=<?php echo $member['id']; ?>">View</a> |
                    <a href="edit.php?id=<?php echo $member['id']; ?>">Edit</a> |
                    <a href="delete.php?id=<?php echo $member['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
