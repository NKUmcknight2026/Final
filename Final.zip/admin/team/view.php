<?php
require_once 'team.php';
require_once '../../db.php'; // Ensure the correct path to db.php for the database connection

// Get the team member ID from the query string
$id = $_GET['id'] ?? null;

if ($id) {
    $member = getTeamMemberById($id);
    if (!$member) {
        echo "Team member not found.";
        exit;
    }
} else {
    echo "No team member ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Team Member Details</title>
</head>
<body>
    <h1>Team Member Details</h1>
    <p><strong>ID:</strong> <?php echo htmlspecialchars($member['id']); ?></p>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($member['Name']); ?></p>
    <p><strong>Role:</strong> <?php echo htmlspecialchars($member['Role']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($member['Email']); ?></p>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($member['phone']); ?></p>

    <a href="index.php">Back to Team Members</a>
</body>
</html>
