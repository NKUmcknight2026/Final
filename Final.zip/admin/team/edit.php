<?php
require_once 'team.php';
$id = $_GET['id'];
$member = getTeamMemberById($id);  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'Name' => $_POST['Name'],
        'Role' => $_POST['Role'],
        'Email' => $_POST['Email'],
        'phone' => $_POST['phone']
    ];
    updateTeamMember($id, $data); 
    header("Location: detail.php?id=" . $id);  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Team Member</title>
</head>
<body>
    <h1>Edit Team Member</h1>
    <form method="post">
        <label>Name:</label>
        <input type="text" Name="Name" value="<?php echo $member['Name']; ?>" required><br>
        <label>Position:</label>
        <input type="text" Name="Role" value="<?php echo $member['Role']; ?>" required><br>
        <label>Email:</label>
        <input type="Email" Name="Email" value="<?php echo $member['Email']; ?>" required><br>
        <label>Phone:</label>
        <input type="text" Name="phone" value="<?php echo $member['phone']; ?>" required><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
