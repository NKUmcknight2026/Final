<?php
class JSONHelper {
    // Read all items from a JSON file in the current directory
    public static function readFromFile($pages) {
        if (!file_exists($pages)) {
            return []; // Return an empty array if the file does not exist
        }
        $json = file_get_contents($pages);
        return json_decode($json, true) ?? [];
    }

    // Write data to a JSON file in the current directory
    public static function writeToFile($pages, $data) {
        $json = json_encode($data, JSON_PRETTY_PRINT);
        file_put_contents($pages, $json);
    }

    // Add a new item to the JSON file in the current directory
    public static function addItem($pages, $item) {
        $data = self::readFromFile($pages);
        $item['id'] = self::generateId($data); // Assign a new unique ID
        $data[] = $item;
        self::writeToFile($pages, $data);
    }

    // Update an existing item in the JSON file in the current directory
    public static function updateItem($pages, $id, $updatedData) {
        $data = self::readFromFile($pages);
        foreach ($data as &$item) {
            if ($item['id'] == $id) {
                $item = array_merge($item, $updatedData);
                self::writeToFile($pages, $data);
                return true;
            }
        }
        return false;
    }

    // Delete an item from the JSON file in the current directory
    public static function deleteItem($pages, $id) {
        $data = self::readFromFile($pages);
        foreach ($data as $key => $item) {
            if ($item['id'] == $id) {
                unset($data[$key]);
                self::writeToFile($pages, array_values($data)); // Re-index the array
                return true;
            }
        }
        return false;
    }

    // Generate a unique ID based on the current data
    private static function generateId($data) {
        $maxId = 0;
        foreach ($data as $item) {
            if ($item['id'] > $maxId) {
                $maxId = $item['id'];
            }
        }
        return $maxId + 1;
    }
}
