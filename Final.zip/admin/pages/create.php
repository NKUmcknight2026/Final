<?php
require_once 'pages.php';  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'content' => $_POST['content']
    ];
    createPage($data);  
    header("Location: index.php");  
    exit;
}
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../../css/styles.css">

<head>
    <title>Create New Page</title>
</head>
<body>
    <h1>Create Page</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" required><br>
        <label>Content:</label>
        <textarea name="content" required></textarea><br>
        <button type="submit">Create</button>
    </form>
</body>
</html>
