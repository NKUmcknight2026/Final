<?php
class PageManager {
    private $filePath;

    public function __construct($filePath) {
        $this->filePath = $filePath;
        if (!file_exists($this->filePath)) {
            file_put_contents($this->filePath, json_encode([])); 
        }
    }

    public function getAllPages() {
        $json = file_get_contents($this->filePath);
        return json_decode($json, true) ?? [];
    }

    public function getPageById($id) {
        $pages = $this->getAllPages();
        foreach ($pages as $page) {
            if ($page['id'] == $id) {
                return $page;
            }
        }
        return null;
    }

    public function createPage($pageData) {
        $pages = $this->getAllPages();
        $pageData['id'] = $this->generateId($pages);
        $pages[] = $pageData;
        $this->saveAllPages($pages);
    }

    public function updatePage($id, $updatedData) {
        $pages = $this->getAllPages();
        foreach ($pages as &$page) {
            if ($page['id'] == $id) {
                $page = array_merge($page, $updatedData);
                $this->saveAllPages($pages);
                return true;
            }
        }
        return false;
    }

    public function deletePage($id) {
        $pages = $this->getAllPages();
        foreach ($pages as $key => $page) {
            if ($page['id'] == $id) {
                unset($pages[$key]);
                $this->saveAllPages(array_values($pages)); 
                return true;
            }
        }
        return false;
    }

    private function saveAllPages($pages) {
        file_put_contents($this->filePath, json_encode($pages, JSON_PRETTY_PRINT));
    }

    private function generateId($pages) {
        $maxId = 0;
        foreach ($pages as $page) {
            if ($page['id'] > $maxId) {
                $maxId = $page['id'];
            }
        }
        return $maxId + 1;
    }
}
